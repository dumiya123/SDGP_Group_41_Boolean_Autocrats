export const mockCardProps = [
  {
    expenseType: "Rent",
    topIconName: "home",
    setBudget: "500",
    spentAmount: "400",
  },
  {
    expenseType: "Food",
    topIconName: "fast-food",
    setBudget: "1000",
    spentAmount: "500",
  },
  {
    expenseType: "Travelling",
    topIconName: "train",
    setBudget: "300",
    spentAmount: "200",
  },
  {
    expenseType: "Tuition",
    topIconName: "book",
    setBudget: "500",
    spentAmount: "400",
  },
  {
    expenseType: "Clothes",
    topIconName: "shirt",
    setBudget: "800",
    spentAmount: "100",
  },
];
