import React, { useState } from 'react';
import { View, Image, SafeAreaView, ScrollView, StyleSheet, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import SetButton from '../../../../../components/SetButtons/setButton';
import PasswordInput from '../../../../../components/Text&PasswordInputField/passwordInput';
import SectionTitle from '../../../../../components/SettingsComponents/SectionTitle';
import forgetPwImg from '../../../../../pages/forget-password-pages/forget-password-images/lock.png';
import SubtitleComponent from "../../../../../components/SettingsComponents/Subtittle";
import TextInputField from '../../../../../components/TextInputField';

const UserNameChange = () => {
  const navigation = useNavigation();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleChangeUsername = async () => {
    try {
      // Verify existing user's password with the backend
      const passwordVerified = await verifyPassword(password);

      if (passwordVerified) {
        // If password is verified, proceed to change the username
        const usernameChanged = await changeUsername(username);
        if (usernameChanged) {
          // Navigate to confirmation screen or perform any other action
          navigation.navigate('Username Change Confirmation');
        } else {
          // Handle case where username change failed
          Alert.alert('Error', 'Failed to change username. Please try again.');
        }
      } else {
        // Handle case where password verification failed
        Alert.alert('Invalid Password', 'The entered password is incorrect. Please try again.');
      }
    } catch (error) {
      console.error('Error:', error);
      // Handle other errors if necessary
      Alert.alert('Error', 'An error occurred. Please try again later.');
    }
  };

  const verifyPassword = async (password) => {
    // Implement logic to verify password with backend
    // Example:
    // const response = await fetch('VERIFY_PASSWORD_ENDPOINT', {
    //   method: 'POST',
    //   body: JSON.stringify({ password }),
    // });
    // const data = await response.json();
    // return data.passwordVerified;

    // For demonstration purposes, assuming password verification is successful
    return true;
  };

  const changeUsername = async (newUsername) => {
    // Implement logic to change username with backend
    // Example:
    // const response = await fetch('CHANGE_USERNAME_ENDPOINT', {
    //   method: 'POST',
    //   body: JSON.stringify({ newUsername }),
    // });
    // const data = await response.json();
    // return data.usernameChanged;

    // For demonstration purposes, assuming username change is successful
    return true;
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView Style={styles.scrollViewContent}>
        <View style={styles.content}>
          <Image source={forgetPwImg} style={styles.image} />
          <SectionTitle title={"Change Username"} />
          <SubtitleComponent title={"Enter your new Username and existing password here!"} />
          <TextInputField
            placeholder="New Username"
            value={username}
            onChangeText={(text) => setUsername(text)}
            iconName="person"
          />
          <PasswordInput
            value={password}
            onChangeText={setPassword}
            placeholder="Password"
          />
        </View>
        <View style={styles.btn}>
          <SetButton
            onPress={handleChangeUsername}
            title="Confirm"
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3F8FF',
  },
  scrollViewContent: {
    flexGrow: 1,
  },
  content: {
    padding: 20,
    alignItems: 'center',
    marginBottom: 50,
  },
  image: {
    width: '100%',
    height: 200,
    resizeMode: 'contain',
    marginBottom: 20,
  },
  btn: {
    marginTop: 100,
  }
});

export default UserNameChange;
