import React, { useState } from 'react';
import { View, Image, SafeAreaView, ScrollView, StyleSheet, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import SetButton from '../../../../../components/SetButtons/setButton';
import PasswordInput from '../../../../../components/Text&PasswordInputField/passwordInput';
import SectionTitle from '../../../../../components/SettingsComponents/SectionTitle';
import forgetPwImg from '../../../../../pages/forget-password-pages/forget-password-images/lock.png';
import SubtitleComponent from "../../../../../components/SettingsComponents/Subtittle";
import TextInputField from '../../../../../components/TextInputField';

const UserEmailChange = () => {
  const navigation = useNavigation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleChangeEmail = async () => {
    try {
      // Verify existing user's password with the backend
      const passwordVerified = await verifyPassword(password);

      if (passwordVerified) {
        // If password is verified, proceed to change the email
        const emailChanged = await changeEmail(email);
        if (emailChanged) {
          // Navigate to confirmation screen or perform any other action
          navigation.navigate('Email Change Confirmation');
        } else {
          // Handle case where email change failed
          Alert.alert('Error', 'Failed to change email. Please try again.');
        }
      } else {
        // Handle case where password verification failed
        Alert.alert('Invalid Password', 'The entered password is incorrect. Please try again.');
      }
    } catch (error) {
      console.error('Error:', error);
      // Handle other errors if necessary
      Alert.alert('Error', 'An error occurred. Please try again later.');
    }
  };

  const verifyPassword = async (password) => {
    // Implement logic to verify password with backend
    // Example:
    // const response = await fetch('VERIFY_PASSWORD_ENDPOINT', {
    //   method: 'POST',
    //   body: JSON.stringify({ password }),
    // });
    // const data = await response.json();
    // return data.passwordVerified;

    // For demonstration purposes, assuming password verification is successful
    return true;
  };

  const changeEmail = async (newEmail) => {
    // Implement logic to change email with backend
    // Example:
    // const response = await fetch('CHANGE_EMAIL_ENDPOINT', {
    //   method: 'POST',
    //   body: JSON.stringify({ newEmail }),
    // });
    // const data = await response.json();
    // return data.emailChanged;

    // For demonstration purposes, assuming email change is successful
    return true;
  };

  const handleButtonPress = () => {
    // Handle button press to change email
    handleChangeEmail();
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={{ flexGrow: 1 }}>
        <View style={styles.content}>
          <Image source={forgetPwImg} style={styles.image} />
          <SectionTitle title={"Change Email Address"} />
          <SubtitleComponent title={"Enter your new Email address and existing password here!"} />
          <TextInputField
            placeholder="New email"
            value={email}
            onChangeText={(text) => setEmail(text)}
            iconName="email"
          />
          <PasswordInput
            value={password}
            onChangeText={setPassword}
            placeholder="Password"
          />
        </View>
        <View style={styles.btn}>
          <SetButton
            onPress={handleButtonPress}
            title="Confirm"
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3F8FF',
  },
  content: {
    padding: 20,
    alignItems: 'center',
    marginBottom: 50,
  },
  image: {
    width: '100%',
    height: 200,
    resizeMode: 'contain',
    marginBottom: 20,
  },
  btn: {
    marginTop: 100,
  }
});

export default UserEmailChange;
