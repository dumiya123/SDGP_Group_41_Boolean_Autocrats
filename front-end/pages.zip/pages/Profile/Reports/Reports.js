import React from "react";
import { Text } from "react-native";   

const Reports = () => {
    return (
        <Text>Reports</Text>
    );
};

export default Reports;
